package com.enigma.dio.tictactoe.interfaces

interface TGame {

    fun resetBoard()
    fun markBoard()
}