package com.enigma.dio.tictactoe.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.enigma.dio.tictactoe.R
import com.enigma.dio.tictactoe.interfaces.TGame


class BoardFragment : Fragment() {

    private lateinit var boardHandler : TGame

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        boardHandler = activity as TGame
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_board, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = BoardFragment()
    }
}
